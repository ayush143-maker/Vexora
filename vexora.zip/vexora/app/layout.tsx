import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Vexora — Virtual Private Servers built for speed",
  description:
    "Vexora provisions high-performance VPS infrastructure across global regions, with NVMe storage, full root access, and sub-minute deploys.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;600;700&family=IBM+Plex+Sans:wght@400;500;600&family=JetBrains+Mono:wght@400;500&display=swap"
          rel="stylesheet"
        />
      </head>
      <body>{children}</body>
    </html>
  );
}
